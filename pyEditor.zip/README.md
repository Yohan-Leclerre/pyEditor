# Welcome!

Hello, Thanks for downloading pyEditor!

# Requierments

Python 3